package com.supportportal.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
public class Questions {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(nullable = false, updatable = false)
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private Long id;
	private String quetion;
	private String userAnswer;
	private String answer;
	private String[] codeSinppet;
	private String progress;

	public String getProgress() {
		return progress;
	}

	public void setProgress(String progress) {
		this.progress = "100% Pass";
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getQuetion() {
		return quetion;
	}

	public void setQuetion(String quetion) {
		this.quetion = quetion;
	}

	
	public String getUserAnswer() {
		return userAnswer;
	}

	public void setUserAnswer(String userAnswer) {
		this.userAnswer = userAnswer;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String[] getCodeSinppet() {
		return codeSinppet;
	}

	public void setCodeSinppet(String[] codeSinppet) {
		this.codeSinppet = codeSinppet;
	}

	
	public Questions(String quetion, String userAnswer, String answer, String[] codeSinppet, String progress) {
	
		this.quetion = quetion;
		this.userAnswer = userAnswer;
		this.answer = answer;
		this.codeSinppet = codeSinppet;
		this.progress = progress;
	}

	public Questions() {

	}

}
