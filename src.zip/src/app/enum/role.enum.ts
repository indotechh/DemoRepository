export enum Role {
  SUPER_ADMIN = 'ROLE_SUPER_ADMIN',
  
  USER = 'ROLE_USER',

}
