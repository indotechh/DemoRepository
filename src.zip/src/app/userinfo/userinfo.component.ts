import { Component, OnInit } from '@angular/core';
import { NotificationService } from '../service/notification.service';
import { AuthenticationService } from '../service/authentication.service';
import { Router } from '@angular/router';
import { Role } from '../enum/role.enum';
import { User, questionList } from '../model/user';
import { environment } from 'src/environments/environment';
import { NotificationType } from '../enum/notification-type.enum';
import { FormControl } from '@angular/forms';
import { UserService } from '../service/user.service';
import { Subscription } from 'rxjs';
import { HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { HeaderType } from '../enum/header-type.enum';
const urlContext = environment.context;
@Component({
  selector: 'app-userinfo',
  templateUrl: './userinfo.component.html',
  styleUrls: ['./userinfo.component.css']
})
export class UserinfoComponent implements OnInit {
  public user: User;
  private username:string;
  private token:string;
   items =IMAGEPATH;
    
   userAnswer :string;
   quesionList : questionList[]=[];
   
   showQuestions:boolean=false;
   timeLeft: number = 1000;
   interval;
   answer:any;
   private subscriptions: Subscription[] = [];
   checkedRoles:boolean=false;
  constructor(private router: Router, private authenticationService: AuthenticationService,
    private notificationService: NotificationService,private userService:UserService) {  this.answer = 0; }

  ngOnInit(): void {
    this.user = this.authenticationService.getUserFromLocalCache();
    this.username=this.user.username;
 this.token=this.authenticationService.getToken();


 
 for (var i = 0; i < 3; i++) {
   var idx = Math.floor(Math.random() * this.items.length);
   this.quesionList.push(this.items[idx]);
   this.items.splice(idx, 1);
 }
 
 console.log(this.quesionList);

  }
  public onLogOut(): void {
    this.authenticationService.logOut();
    this.router.navigate(['/login']);
    this.sendNotification(NotificationType.SUCCESS, `You've been successfully logged out`);
  }
  private sendNotification(notificationType: NotificationType, message: string): void {
    if (message) {
      this.notificationService.notify(notificationType, message);
    } else {
      this.notificationService.notify(notificationType, 'An error occurred. Please try again.');
    }
  }

  quesGreetNotification() {
    this.checkedRoles=true;
    this.showQuestions=true;
    this.interval = setInterval(() => {
      if(this.timeLeft > 0) {
        this.timeLeft--;
      } 
    },1000)
  
  }
  
  importantRole(){
    this.checkedRoles=true;
  }

  submitAnwser(){
    this.user.questions=this.quesionList;
    const formData = new FormData();
    formData.append('username', this.user.username);
    formData.append('email',this.user.email)
    formData.append('questions',JSON.stringify( this.user.questions));

    this.subscriptions.push(
    this.userService.sendQuesList(formData).subscribe(
      (response: User) => {
        
        this.sendNotification(NotificationType.SUCCESS, `A new account was created for ${response.firstName}.
        Please check your email for password to log in.`);
        this.showQuestions=false;
        this.checkedRoles=true;
        this.router.navigate(['/login']);
      },
      (errorResponse: HttpErrorResponse) => {
        this.sendNotification(NotificationType.ERROR, errorResponse.error.message);
           }
    )
  );
  }
 
  saveChange( event){
  //   console.log(event);
  //  var userans=event;
  //  console.log(userans);
  //   for(var i=0;i<=this.quesionList.length; i++){
  //       this.products.push({"question":this.quesionList[i].question,"codeSnippet":this.quesionList[i].codeSnippet,"answer":this.quesionList[i].answer,"userAnswer":userans})
  //   }
   
  }
 
}




export const IMAGEPATH = [
{ question:'Which of the following would the below Java coding snippet return as its output?', codeSnippet:urlContext + 'assets/img/question1.png',answer:'1', userAnswer:'1'},  
 {question: 'Which of the following combinations would the below Java coding snippet print?', codeSnippet:urlContext + 'assets/img/question1.png', answer:'1', userAnswer:'1'} , 
 {question:'What would be the outcome of following Java coding snippet?', codeSnippet:urlContext + 'assets/img/question3.png',answer:'Type mismatch error', userAnswer:'Type mismatch error'} , 
 {question:'What would the below Java coding snippet print?', codeSnippet:urlContext + 'assets/img/question4.png', answer:'Welcome', userAnswer:'Welcome'} , 
 {question:'Which of the following values would the below Java coding snippet print in results?', codeSnippet:urlContext + 'assets/img/question5.png', answer:'1', userAnswer:'1'},  
 {question:'Which of the following is the result of the following Java code?',  codeSnippet:urlContext + 'assets/img/question6.png', answer:'Nothing would get printed.', userAnswer:'Nothing would get printed'},  
 {question:'What is the result of the following Java coding snippet?', codeSnippet:urlContext + 'assets/img/question7.png', answer:'Type mismatch error', userAnswer:'Type mismatch error'},  
 {question:'What would the following function yield when called? If a is false and b is true,', codeSnippet:urlContext + 'assets/img/question8.png',  answer:' None', userAnswer:'None'},  
 {question:'What would the following Java coding snippet return as its output?',  codeSnippet:urlContext + 'assets/img/question9.png',answer:'Java Quiz', userAnswer:'Java Quiz'},  
 {question:'What does the following Java coding snippet print?', codeSnippet:urlContext + 'assets/img/question10.png',answer:'abcdef', userAnswer:'abcdef'},  
 {question:'What will be the output of following Java coding snippet?',  codeSnippet:urlContext + 'assets/img/question5.png',answer:'abc', userAnswer:'abc'},  
 {question:'What would the following Java coding snippet return?', codeSnippet:urlContext + 'assets/img/question5.png',answer:'Nothing would get printed', userAnswer:'Nothing would get printed'},  
 {question:'What is the outcome of the below Java code?', codeSnippet:urlContext + 'assets/img/question5.png', answer:'Compilation time error', userAnswer:'Compilation time error'},  
 {question:'What does the following Java coding snippet yield?', codeSnippet:urlContext + 'assets/img/question5.png', answer:'Compile time error', userAnswer:'Compile time error'},  
 {question:'Which of the following is the result of the below Java coding snippet?', codeSnippet:urlContext + 'assets/img/question5.png',answer:'7', userAnswer:'7'},  

]
