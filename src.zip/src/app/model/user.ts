export class User {
  public userId: string;
  public firstName: string;
  public lastName: string;
  public username: string;
  public email: string;
  public active: boolean;
  public notLocked: boolean;
  public role: string;
  public authorities: [];
  public questions:questionList[];

  constructor() {
    this.userId = '';
    this.firstName = '';
    this.lastName = '';
    this.username = '';
    this.email = '';
    
    this.active = false;
    this.notLocked = false;
    this.role = '';
    this.authorities = [];
    
  }


}

export class questionList {
  question: any;
  codeSnippet: any;
  answer:any;
  userAnswer:any;
}