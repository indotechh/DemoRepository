import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { UserComponent } from './user/user.component';
import { AuthenticationGuard } from './guard/authentication.guard';
import { UserinfoComponent } from './userinfo/userinfo.component';
import { UserGuard } from './guard/user.guard';
import { Role } from './enum/role.enum';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'user/management', component: UserComponent, canActivate: [AuthenticationGuard] , data: { roles: [Role.SUPER_ADMIN] }},
  {path: 'user/information', component:UserinfoComponent,canActivate:[UserGuard] , data: { roles: [Role.USER]}},
  { path: '', redirectTo: '/login', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
