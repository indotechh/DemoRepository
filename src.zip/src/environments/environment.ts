
export const environment = {
  apiurl:'http://localhost:8081',
  production: false,
  context:''
};
